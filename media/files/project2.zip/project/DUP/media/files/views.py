from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from .models import User
import calendar,datetime
def timetable(request):
    if request.method == 'POST':
        time = request.POST
        if time.get('Date') and time.get('Month'):
            date=request.POST
            day=date.Day
            month=date.Month
            year="2020"
            dayNumber = calendar.weekday(year, month, day) 
            return HttpResponseRedirect("http://localhost:8000//"+str(dayNumber))
        else:
            return render(request,'timetable/value.html',{"error":1})
    else:
        return render(request,'timetable/value.html')
def day(request, album_id):
    return render(request,'login/day.html',{'User':album_id})


